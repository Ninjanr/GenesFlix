class ThemeManager {
  constructor(toggleSelector) {
      this.toggle = document.querySelector(toggleSelector);
      this.root = document.documentElement;

      // Carrega o tema salvo no localStorage
      const savedTheme = localStorage.getItem('theme') || 'dark';
      this.root.setAttribute('data-theme', savedTheme);

      // Ajusta o estado inicial do botão, se existir
      if (this.toggle) {
          if (savedTheme === 'light') {
              this.toggle.classList.add('active');
          }

          // Adiciona evento de clique para alternar o tema
          this.toggle.addEventListener('click', () => this.toggleTheme());
      }
  }

  toggleTheme() {
      const isLightMode = this.root.getAttribute('data-theme') === 'light';
      const newTheme = isLightMode ? 'dark' : 'light';

      // Atualiza o tema e salva no localStorage
      this.root.setAttribute('data-theme', newTheme);
      localStorage.setItem('theme', newTheme);

      // Atualiza o estado do botão
      if (this.toggle) {
          this.toggle.classList.toggle('active', !isLightMode);
      }
  }
}

// Instancia o gerenciador de tema automaticamente, se necessário
document.addEventListener('DOMContentLoaded', () => {
  new ThemeManager('#themeToggle');
});


