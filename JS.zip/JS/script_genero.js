 // Carregar comentários do filme
 function loadComments(idFilme) {
    fetch(`get_comments.php?id_filme=${idFilme}`)
        .then(response => response.json())
        .then(data => {
            commentsContainer.innerHTML = '';
            if (data.length) {
                data.forEach(comment => {
                    const commentDiv = document.createElement('div');
                    commentDiv.className = 'comment';
                    commentDiv.innerHTML = `
                <img src="${comment.profile_picture}" alt="Foto de Perfil" class="profile-thumbnail" id="profileIcon">
                <br>    
                <strong>${comment.full_name}</strong>: ${comment.comentario}
                <br><small>${comment.data_comentario}</small>
                `;
                    commentsContainer.appendChild(commentDiv);
                });
            } else {
                commentsContainer.innerHTML = '<p>Seja o primeiro a comentar!</p>';
            }
        })
        .catch(err => console.error('Erro ao carregar comentários:', err));
}